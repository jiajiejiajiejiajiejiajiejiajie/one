import os
import random
import time
import requests
import re
from urllib import parse
class downloadsouhu():
    ss=requests.session()
    runStatus = True
    zeroList='0000000'
    saveFilePath = r"D:\爬取1"
    seachURL="https://so.tv.sohu.com/mts?wd={}&c=0&v=0&length=0&limit=0&site=0&o=0&p={}&st=0&suged=&filter=0&time=1698219603971&code=gNykTMxgDO1YDN5ATNClTJGJUJ4UUJzgTJ3IUJ4UUJFJUJ5gTJ4UUJ"
    descPageURL="https://tv.sohu.com/v/{}.html"
    videolistURL="https://my.tv.sohu.com/play/getvideolist.do?callback=jQuery17202743045934073225_1667114384371&ssl=0&playlistid={}&pagesize=30&order=0&pagenum={}&_=1667114715037"
    susURL="https://my.tv.sohu.com/play/videonew.do?vid={}&ver=1&ssl=1&referer=https%3A%2F%2Ftv.sohu.com%2Fv%2FcGwvOTQwNzQ1OS8xOTc3Mjk4MzYuc2h0bWw%3D.html&t=1667118432209"
    dlURL="https://data.vod.itc.cn/ip?new={}&num=1&key=oOQd1--RfGTVlbizS3GNepyN-8nT5i4P&ch=my&pt=1&pg=2&prod=h5n&uid=16671081762955470875"
    def GetVidsAndRun(self,wd):
        pageNuber = 1
        playListId = None
        self.ss = requests.session()
        # self.ss.verify=False
        self.ss.headers={'Host':'so.tv.sohu.com',
'Connection':'keep-alive',
'sec-ch-ua':'"Chromium";v="118","GoogleChrome";v="118","Not=A?Brand";v="99"',
'sec-ch-ua-mobile':'?0',
'sec-ch-ua-platform':'"Windows"',
'Upgrade-Insecure-Requests':'1',
'User-Agent':'Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/118.0.0.0Safari/537.36',
'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
'Sec-Fetch-Site':'same-origin',
'Sec-Fetch-Mode':'navigate',
'Sec-Fetch-User':'?1',
'Sec-Fetch-Dest':'document',
'Referer':'https://so.tv.sohu.com/mts?wd=%E8%89%BE%E8%B7%83%E8%BF%9B&c=0&v=0&length=0&limit=0&site=0&o=0&p=1&st=0&suged=&filter=0&time=1698219603971&code=gNykTMxgDO1YDN5ATNClTJGJUJ4UUJzgTJ3IUJ4UUJFJUJ5gTJ4UUJ',
'Accept-Encoding':'gzip,deflate,br',
'Accept-Language':'zh-CN,zh;q=0.9,de;q=0.8',
'Cookie':'SUV=230913102333VS59;clt=1694571813;cld=20230913102333;ch_key=50e48c6168d7b908;ifoxinstalled=false;newpuid=16968678288624637553;fuid=16968678288678954196;landingrefer=https%3A%2F%2Fwww.baidu.com%2Flink%3Furl%3D7FKViFuJ6KhHmyl1ZbHtJqSz2HKK9kaNpH0r3903oH_%26wd%3D%26eqid%3Dfc42bd0000019cb600000006652425eb;reqtype=pc;gidinf=x099980109ee17c029d2bd03b000b9fb796fe072a899;pgc_wakeup20231025=1;beans_dmp=%7B%2210191%22%3A1696867830%2C%22admaster%22%3A1696867830%2C%22shunfei%22%3A1696867830%2C%22reachmax%22%3A1698205323%2C%22lingji%22%3A1696867830%2C%22yoyi%22%3A1696867830%2C%22ipinyou%22%3A1696867830%2C%22ipinyou_admaster%22%3A1696867830%2C%22miaozhen%22%3A1698205323%2C%22diantong%22%3A1696867830%2C%22huayang%22%3A1696867830%2C%22precisionS%22%3A1696867830%2C%22qunyi%22%3A1696867830%7D;beans_dmp_done=1;IPLOC=CN3100;iwt_uuid=3b9e8c38-5973-4277-80a1-8e154a47a983;beans_freq=1;JSESSIONID=7083E85173EE4E4E5E3D8F71504E961C;t=1698223054304'}
        while self.runStatus:
            rt = self.GetHttpBody(self.seachURL.format(parse.quote_plus(wd), pageNuber))
            rt = rt.text.encode("utf8").decode("utf8")
            rf = re.findall(r'''<a href="//tv\.sohu\.com/v/(.*?)\.html''', rt)
            self.DescPageRun(rf)
            print(rf)
            if "下一页" not in rt:
                print("已经下载完最后一页")
                pageNuber=1
                return
    def DescPageRun(self,descPageList):
        for i in descPageList:
            print(self.descPageURL.format(i))
            rt = requests.get(self.descPageURL.format(i))
            rt=rt.text
            # print(rt)
            rf = re.findall(r"vid: '(.+?)'", rt)
            if rf:
                vid = rf[0]
            else:
                print("vid不存在")
                continue
            rf = re.findall(r"title: '(.+?)'", rt)
            if rf:
                title = rf[0]
            else:
                print("title不存在")
                continue
            print( title, vid)
            self.DownLoadFileList(0, title, vid)

    def DownLoadFileList(self,fileCount,fileName, vid):
        fileName = self.zeroList[0:len(self.zeroList)-len(str(fileCount))]+str(fileCount) + "_"+re.sub(r"\\|\/|\:|\*|\?|\"|\<|\>|\|| ", "", fileName)
        sus = self.GetSus(vid)
        mp4Names = []
        for j in range(0, len(sus)):
            mp4Name = fileName + "_"+ str(j) + '.mp4'
            if ".com" in sus[j]:
                DLURL=sus[j]
            else:
                DLURL = requests.get(sus[j])
                if not DLURL:
                    print("下载失败", fileName, sus[j])
                    continue
            mp4Names.append(mp4Name)
            print(DLURL)
            self.DownLoadFile(mp4Name,DLURL)
            time.sleep(random.randint(2, 3))
        self.Mp4MergeCMD(fileName + ".mp4", mp4Names)

    def DownLoadFile(self,fileName, DLURL):
        res = requests.get(DLURL)
        f = open(fileName, 'wb+')
        try:
            f.write(res.content)
        finally:
            f.close()
    def GetHttpBody(self,url):
        for k in range(10):
            try:
                rt = self.ss.get(url)
                return rt
            except:
                self.ss.close()
                time.sleep(5)
                self.ss = requests.session()
    def GetSus(self,vid):
        rt=requests.get(self.susURL.format(vid))
        rt = rt.content
        rt = rt.decode("utf-8")
        print(rt)
        sus = re.findall(r'"mp4PlayUrl":\["(.+?)\"]', rt)
        print(sus)
        return sus[0].split(r'","')
    def GetDLURL(self,su):
        rt = self.GetHttpBody(self.dlURL.format(su))
        rt = rt.content
        rt = rt.decode("utf-8")
        DLURL = re.findall(r'"url":"(.+?)"', rt)
        if DLURL:
            DLURL=DLURL[0]
        else:
            DLURL=None
        return DLURL
    def Mp4MergeCMD(self,videoName,mp4List):
        with open("concat_list.txt","w+", encoding='utf-8') as f:
            concatmp4List=''
            for i in mp4List:
                concatmp4List+= "file " + "'" + i + "'" + "\n"
            f.write(concatmp4List)
        cmd=r'ffmpeg -f concat -safe 0 -i concat_list.txt -c copy "{}"'.format(self.saveFilePath+"\\"+videoName)
        print(cmd)
        os.system(cmd)
        os.remove("concat_list.txt")
        for file in mp4List:
            os.remove(file)
        pass

dlsh=downloadsouhu()
# dlsh.DownLoadFile("aa",'magnet:?xt=urn:btih:D443E48ABD96C72340692767DD51FD79911F1172')
dlsh.GetVidsAndRun("艾跃进")
# dlsh.Mp4Merge("南街村党委书记王宏斌汇报材料上---------.mp4",["南街村党委书记王宏斌汇报材料上0.mp4","南街村党委书记王宏斌汇报材料上1.mp4","南街村党委书记王宏斌汇报材料上2.mp4","南街村党委书记王宏斌汇报材料上3.mp4","南街村党委书记王宏斌汇报材料上4.mp4","南街村党委书记王宏斌汇报材料上5.mp4","南街村党委书记王宏斌汇报材料上6.mp4","南街村党委书记王宏斌汇报材料上7.mp4","南街村党委书记王宏斌汇报材料上8.mp4"])
